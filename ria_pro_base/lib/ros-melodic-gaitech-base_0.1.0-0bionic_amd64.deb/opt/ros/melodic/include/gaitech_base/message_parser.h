/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@gaitech.co.kr>

Copyright (c) 2020, Gaitech Korea Co., Ltd.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef GAITECH_BASE__MESSAGE_PARSER_H_
#define GAITECH_BASE__MESSAGE_PARSER_H_

#include <string>
#include <vector>
#include <bitset>
#include <chrono>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include "ros/ros.h"
#include "std_msgs/Bool.h"
#include "sensor_msgs/Range.h"

#include "gaitech_base/message_type.h"

using namespace std;

class MessageParser
{
public:
  MessageParser(Feedback& feedback, std_msgs::Bool& estop_state, std_msgs::Bool& docked, size_t num_channels);

  virtual ~MessageParser() = default;

  /**
   * \brief Parse the message
   * \param msg Message read through serial communication
   */
  void parse(const string& msg);

  /**
   * \brief Parse the error message
   * \param index Index of the controller
   * \param flags Number converted to binary number
   */
  void faultFlags(const uint8_t index, const uint16_t flags);

  /**
   * \brief Convert RPM to angular velocity
   * \param rpm Motor's RPM
   */
  double toVelocity(const double rpm);

  /**
   * \brief Convert encoder count to radian
   * \param enc Motor's encoder count
   */
  double toRad(const double enc);

  /// Feedback related
  Feedback& feedback_;

  // Estop state
  std_msgs::Bool& estop_state_;

  // Docking state
  std_msgs::Bool& docked_;

  /// Number of channels
  size_t num_channels_;

  /// PPR(pulse per revolution) of the motor
  uint32_t ppr_;

  /// For debugging
  chrono::system_clock::time_point last_time_;
  int16_t max_latency_;

private:
};

#endif  // GAITECH_BASE__MESSAGE_PARSER_H_
/*
Software License Agreement (BSD License)

Authors : Brighten Lee <shlee@gaitech.co.kr>

Copyright (c) 2020, Gaitech Korea Co., Ltd.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef GAITECH_BASE__GAITECH_CONTROLLER_H_
#define GAITECH_BASE__GAITECH_CONTROLLER_H_

#include <string>
#include <vector>
#include <cmath>
#include <thread>

#include "ros/ros.h"
#include "std_msgs/Bool.h"

#include "gaitech_serial/serial.h"
#include "gaitech_base/message_parser.h"
#include "gaitech_base/controller_channel.h"

using namespace std;

class GaitechController : public MessageParser
{
public:
  GaitechController(string robot, vector<string> joint, double wheel_radius, double max_speed, double max_rpm,
                    string port, int32_t baud, Feedback& feedback, std_msgs::Bool& estop_state, std_msgs::Bool& docked);

  virtual ~GaitechController();

  /**
   * \brief Initialize
   */
  bool init();

  /**
   * \brief Initial setting for serial communication
   */
  bool connect();

  /**
   * \brief Read message
   */
  void read();

  /**
   * \brief Reset the encoder counter
   */
  bool resetEncCount();

  /**
   * \brief Send the velocity command
   * \param msg Velocity command message for each motors (rad)
   */
  void sendCommand(const Command& cmd);

  /**
   * \brief Limit to below maximum speed
   * \param speed Angular velocity to send
   * \return If it is faster than the maximum speed, the maximum speed returns
   */
  double limitMaxSpeed(const double speed);

  /**
   * \brief Convert angular velocity to RPM
   * \param w Angular velocity
   * \return RPM value
   */
  double toRPM(const double w);

  /**
   * \brief Stop MicroBasicScript Operation
   */
  void stopScript();

  /**
   * \brief Start MicroBasicScript Operation
   */
  void startScript();

private:
  /// Robot name
  string robot_;

  /// Robot parameters
  double wheel_radius_, max_speed_, max_rpm_;

  /// Class for serial communication
  serial::Serial serial_;

  /// Serial parameters
  string port_;
  int32_t baud_;

  /// Class for communication interfaces on each controller
  vector<ControllerChannel> channel_;
};

#endif  // GAITECH_BASE__GAITECH_CONTROLLER_H_